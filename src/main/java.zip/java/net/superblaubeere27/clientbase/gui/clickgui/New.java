package net.superblaubeere27.clientbase.gui.clickgui;


import java.awt.Color;
import java.io.IOException;

import net.superblaubeere27.clientbase.ClientBase;
import net.superblaubeere27.clientbase.Value.Mode;
import net.superblaubeere27.clientbase.Value.Numbers;
import net.superblaubeere27.clientbase.Value.Option;
import net.superblaubeere27.clientbase.Value.Value;
import net.superblaubeere27.clientbase.modules.Module;
import net.superblaubeere27.clientbase.modules.ModuleCategory;
import net.superblaubeere27.clientbase.utils.fontRenderer.FontLoaders;
import net.superblaubeere27.clientbase.utils.render.UiUtils;
import org.lwjgl.input.Mouse;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.util.ResourceLocation;

public class New
        extends GuiScreen {
    int X=50;
    int Y=50;
    int moveX;
    int moveY;
    int wheely;
    int recty;
    int bg;
    int a;
    boolean move;
    boolean mode=false;
    String category;
    public New() {
    }
    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        if(bg<250) {
            bg+=10;
        }
        UiUtils.drawRect(X, Y, X+400, Y+250, new Color(242,242,242,bg).getRGB());
        UiUtils.drawGradient(X, Y, X+100, Y+250, new Color(26,30,39,bg).getRGB(), new Color(40,52,75,bg).getRGB());
        FontLoaders.Comfortaa28.drawStringWithShadow("Azlips", X+10, Y+15, -1);
        int cy=Y+50;
        int tar=0;
        UiUtils.drawGradientSideways(X, Y+50+recty-5, X+100, Y+50+recty+15, new Color(13,125,227,bg).getRGB(),new Color(0,113,193,bg).getRGB());
        for(ModuleCategory c:ModuleCategory.values()) {
            if(this.category=="Combat") {
                tar=0;
            }
            if(this.category=="Render") {
                tar=20;
            }
            if(this.category=="Movement") {
                tar=40;
            }
            if(this.category=="Player") {
                tar=60;
            }
            if(this.category=="World") {
                tar=80;
            }
            if(recty<tar) {
                recty+=1;
            }
            if(recty>tar) {
                recty-=1;
            }
            //UiUtils.drawImage(new ResourceLocation("VizsuX/ClickGui/"+c.name()+".png"), X+2, cy, 8, 8);
            FontLoaders.Comfortaa18.drawStringWithShadow(c.name(), X+10, cy, -1);

            cy+=20;

        }
        int drawy=Mouse.getDWheel();
        int my=Y+10+wheely;
        if(mouseX>X+100&&mouseX<X+400&&mouseY>this.Y&&mouseY<this.Y+250) {
            if(drawy!=0) {
                if(drawy==120) {
                    wheely+=10;
                }
                if(drawy==-120) {
                    wheely-=10;
                }
            }
        }
        UiUtils.startGlScissor(X+100, Y, 400, 250);
        for(Module m: ClientBase.INSTANCE.moduleManager.getModules()) {
            if(m.getCategory().toString()!=this.category)continue;
            UiUtils.drawRect(X+110, my, X+390, my+30, new Color(13,125,227,bg).getRGB());
            FontLoaders.Comfortaa18.drawStringWithShadow(m.getName(), X+115, my+9, m.getState()?-1:new Color(150,150,150).getRGB());
            if(m.getValues().size()>0) {
                FontLoaders.Comfortaa18.drawString(">", X+380, my+10, -1);
            }

            int vy=my+30;
            int modey=vy+15;
            for(Value v:m.getValues()) {
                if(!(m.getValues()!=null))continue;
                if(v instanceof Option) {
                    UiUtils.drawRect(X+110, vy, X+390, vy+30, new Color(43,55,77,bg).getRGB());
                    UiUtils.drawRoundRect(X+374, vy+8, X+386, vy+20, ((Boolean) v.getValue()).booleanValue()?new Color(13,125,227).getRGB():new Color(120,120,120,bg).getRGB());
                    FontLoaders.Comfortaa18.drawStringWithShadow(v.getName(),X+120,vy+10,-1);
                }
                if(v instanceof Numbers) {
                    Numbers v1;
                    int render;
                    v1 = (Numbers)v;
                    render = (int)(115.0F * (((Number)v1.getValue()).floatValue() - v1.getMinimum().floatValue()) / (v1.getMaximum().floatValue() - v1.getMinimum().floatValue()));
                    UiUtils.drawRect(X+110, vy, X+390, vy+30, new Color(43,55,77,bg).getRGB());
                    UiUtils.drawRect(X+270, vy+17, X+380, vy+18, new Color(150,150,150,bg).getRGB());
                    UiUtils.drawRect(X+270, vy+17, X+270+render, vy+18, new Color(17,127,227,bg).getRGB());
                    UiUtils.drawRoundRect(X+270+render-3, vy+14, X+270+render+3, vy+20	, new Color(17,127,227,bg).getRGB());
                    FontLoaders.Comfortaa18.drawStringWithShadow(v.getName()+":"+v.getValue(),X+120,vy+10,-1);
                    if(mouseX>X+110&&mouseX<X+390+100&&mouseY>vy&&mouseY<vy+30&&Mouse.isButtonDown(0)) {
                        render = (int) v1.getMinimum().doubleValue();
                        double max = v1.getMaximum().doubleValue();
                        double min = v1.getIncrement().doubleValue();
                        double valAbs = mouseX-(this.X+270);
                        double perc = valAbs / 77.2D;
                        perc = Math.min(Math.max(0.0D, perc), 1.0D);
                        double valRel = (max - render) * perc;
                        double val = render + valRel;
                        val = (double)Math.round(val * (1.0D / min)) / (1.0D / min);
                        v1.setValue(Double.valueOf(val));
                    }
                }
                if(v instanceof Mode) {
                    UiUtils.drawRect(X+110, vy, X+390, vy+30, new Color(43,55,77,bg).getRGB());
                    FontLoaders.Comfortaa18.drawStringWithShadow(v.getName(),X+120,vy+10,-1);
                    UiUtils.outlineRect(X+385, vy+8, X+378-FontLoaders.Comfortaa18.getStringWidth(((Mode) v).getModeAsString()), vy+22, 0.5f,new Color(43,55,77,bg).getRGB(), new Color(255,255,255,bg).getRGB());
                    FontLoaders.Comfortaa18.drawStringWithShadow(((Mode) v).getModeAsString(),X+380-FontLoaders.Comfortaa18.getStringWidth(((Mode) v).getModeAsString()),vy+10,-1);
                    for(Enum e:((Mode) v).getModes()) {
                        if(mode) {
                            UiUtils.drawRect(X+403, modey-8, X+480, modey+7,new Color(43,55,77,bg).getRGB());
                            FontLoaders.Comfortaa18.drawStringWithShadow(e.name(),X+405,modey-5,e.name()==((Mode) v).getModeAsString()?-1:new Color(180,180,180).getRGB());
                        }
                        modey+=15;
                    }
                }
                vy+=30;
            }
            my+=m.isSetting()?(m.getValues().size()+1)*30+15:40;
        }
        UiUtils.stopGlScissor();
        if(move) {
            this.X=mouseX-moveX;
            this.Y=mouseY-moveY;
        }
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    public void onGuiClosed() {
        super.onGuiClosed();
    }
    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        if(mouseX>X&&mouseX<X+400&&mouseY>Y&&mouseY<Y+20&&mouseButton==0) {
            move=true;
            this.moveX=mouseX-X;
            this.moveY=mouseY-Y;
        }else {
            move=false;
        }
        int cy=Y+50;
        for(ModuleCategory c:ModuleCategory.values()) {
            if(mouseX>X&&mouseX<X+100&&mouseY>cy-5&&mouseY<cy+15&&mouseButton==0) {
                this.category=c.name();
            }
            cy+=20;
        }
        int drawy=Mouse.getDWheel();
        int my=Y+10+wheely;
        if(mouseX>X+100&&mouseX<X+400&&mouseY>this.Y&&mouseY<this.Y+250) {
            if(drawy!=0) {
                if(drawy==120) {
                    wheely+=10;
                }
                if(drawy==-120) {
                    wheely-=10;
                }
            }
        }
        for(Module m:ClientBase.INSTANCE.moduleManager.getModules()) {
            if(m.getCategory().toString()!=this.category)continue;
            if(mouseX>X+110&&mouseX<X+390+100&&mouseY>my&&mouseY<my+30&&mouseButton==0) {
                m.setState(!m.getState());
            }
            if(mouseX>X+110&&mouseX<X+390+100&&mouseY>my&&mouseY<my+30&&mouseButton==1&&m.getValues().size()>0) {
                m.setSetting(!m.isSetting());
            }
            int vy=my+30;
            int modey=vy+15;
            for(Value v:m.getValues()) {
                if(!m.isSetting())continue;
                if(v instanceof Option) {
                    if(mouseX>X+110&&mouseX<X+390&&mouseY>vy&&mouseY<vy+30&&mouseButton==0) {
                        v.setValue(!((Boolean) v.getValue()).booleanValue());
                    }
                }
                if(v instanceof Mode) {
                    if(mouseX<X+385&&mouseX>X+378-FontLoaders.Comfortaa18.getStringWidth(((Mode) v).getModeAsString())&&mouseY>vy+8&&mouseY<vy+22&&mouseButton==0) {
                        mode=!mode;
                    }
                    for(Enum e:((Mode) v).getModes()) {
                        if(mode) {
                            if(mouseX>X+403&&mouseX<X+480&&mouseY>modey-8&&mouseY<modey+7&&mouseButton==0) {
                                ((Mode) v).setMode(e.name());
                            }
                        }
                        modey+=15;
                    }
                }
                vy+=30;
            }
            my+=m.isSetting()?(m.getValues().size()+1)*30+15:40;
        }
        super.mouseClicked(mouseX, mouseY, mouseButton);
    }
}


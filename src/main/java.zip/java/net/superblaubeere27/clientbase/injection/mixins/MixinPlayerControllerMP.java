package net.superblaubeere27.clientbase.injection.mixins;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.world.WorldSettings;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.superblaubeere27.clientbase.ClientBase;
import net.superblaubeere27.clientbase.modules.modules.combat.Reach;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(PlayerControllerMP.class)
@SideOnly(Side.CLIENT)
public class MixinPlayerControllerMP {
    @Shadow
    private WorldSettings.GameType currentGameType = WorldSettings.GameType.SURVIVAL;

    @Overwrite
    public float getBlockReachDistance()
    {
        if(Minecraft.getMinecraft().thePlayer.isInWater()){
            return this.currentGameType.isCreative() ? 5.0F : 4.5F;
        }else {
            return ClientBase.INSTANCE.moduleManager.getModule(Reach.class).getState() ? Reach.range.getValue().floatValue() : this.currentGameType.isCreative() ? 5.0F : 4.5F;
        }
    }

}
